# installazione e caricamento pacchetti necessari

# installa rvest
install.packages("rvest") 

# chiama rvest library
library(rvest)

#Installazione pacchetto Syuzhet
install.packages("syuzhet")

#Richiamo pacchetto Syuzhet
library("syuzhet")

#Installazione pacchetto Reshape2
install.packages("reshape2")

#Richiamo pacchetto Reshape2
library(reshape2)

#Installazione pacchetto Tidyverse
install.packages("tidyverse")

#Richiamo pacchetto Tidyverse
library(tidyverse)

#utilizzo questo comando per indirizzare al link delle recensioni del libro scelto
my_link <- "https://www.goodreads.com/book/show/13335037-divergent"

# utilizzo questo comando per leggerlo (farla girare più volte finchè non ci mette tempo c'è problema sito web!)
doc <- read_html(my_link)

full_reviews <- doc %>% html_nodes(xpath = "//div[@class='friendReviews elementListBrown']")

#Parte dello Scraping
#iterazione estesa (ottenendo testo, autore e data)
my_reviews <- character()
my_authors <- character()
my_dates <- character()

doc %>% html_nodes(xpath = "//div[@class='friendReviews elementListBrown']")

for(i in 1:length(full_reviews)){
  
  my_reviews[i] <- full_reviews[[i]] %>% html_node(css = "[style='display:none']") %>% html_text() 
  my_authors[i] <- full_reviews[[i]] %>% html_node(css = "[class='user']") %>% html_text()
  my_dates[i] <- full_reviews[[i]] %>% html_node(css = "[class='reviewDate createdAt right']") %>% html_text()
  
}

my_text <- gsub(pattern = "https://www.goodreads.com/book/show/", replacement = "", my_link, fixed = T)

#Salvare tutto
my_df <- data.frame(book = my_text, author = my_authors, date = my_dates, review = my_reviews)

#Scrivere file in csv
write.csv(my_df, file = paste("corpora/Goodreads_", my_text, ".csv", sep = ""))

#Ripetiamo preparazione per il secondo libro scelto!

#utilizzo questo comando per indirizzare al link delle recensioni del libro scelto
my_link <- "https://www.goodreads.com/book/show/8755785-city-of-heavenly-fire"

# utilizzo questo comando per leggerlo (farla girare più volte finchè non ci mette tempo)
doc <- read_html(my_link)

full_reviews <- doc %>% html_nodes(xpath = "//div[@class='friendReviews elementListBrown']")

#Iterazione estesa (ottenendo testo, autore e data)
my_reviews <- character()
my_authors <- character()
my_dates <- character()

for(i in 1:length(full_reviews)){
  
  my_reviews[i] <- full_reviews[[i]] %>% html_node(css = "[style='display:none']") %>% html_text() # improved: we get the hidden text
  my_authors[i] <- full_reviews[[i]] %>% html_node(css = "[class='user']") %>% html_text()
  my_dates[i] <- full_reviews[[i]] %>% html_node(css = "[class='reviewDate createdAt right']") %>% html_text()
  
}

my_text <- gsub(pattern = "https://www.goodreads.com/book/show/", replacement = "", my_link, fixed = T)

#Salviamo tutto
my_df <- data.frame(book = my_text, author = my_authors, date = my_dates, review = my_reviews)

#Operazione per scrivere il tutto in formato csv!
write.csv(my_df, file = paste("corpora/Goodreads_", my_text, ".csv", sep = ""))

#Ripetiamo preparazione per il terzo libro scelto!

#utilizzo questo comando per indirizzare al link delle recensioni del libro scelto
my_link <- "https://www.goodreads.com/book/show/6487308-fallen"

# utilizzo questo comando per leggerlo (farla girare più volte finchè non ci mette tempo)
doc <- read_html(my_link)

full_reviews <- doc %>% html_nodes(xpath = "//div[@class='friendReviews elementListBrown']")

#Iterazione estesa (ottenendo testo, autore e data)
my_reviews <- character()
my_authors <- character()
my_dates <- character()

for(i in 1:length(full_reviews)){
  
  my_reviews[i] <- full_reviews[[i]] %>% html_node(css = "[style='display:none']") %>% html_text() # improved: we get the hidden text
  my_authors[i] <- full_reviews[[i]] %>% html_node(css = "[class='user']") %>% html_text()
  my_dates[i] <- full_reviews[[i]] %>% html_node(css = "[class='reviewDate createdAt right']") %>% html_text()
  
}

my_text <- gsub(pattern = "https://www.goodreads.com/book/show/", replacement = "", my_link, fixed = T)

#Salviamo tutto!
my_df <- data.frame(book = my_text, author = my_authors, date = my_dates, review = my_reviews)

#Operazione per scrivere il tutto in formato csv!
write.csv(my_df, file = paste("corpora/Goodreads_", my_text, ".csv", sep = ""))

#Dedichiamoci alla parte dello Scraping

# Installare e caricare il pacchetto per il riconoscimento linguistico
install.packages("cld2")
library(cld2)

install.packages("tidyverse")
library(tidyverse)

# trova gli indirizzi di tutti i file
all_goodreads_files <- list.files(path = "corpora", pattern = "Goodreads_", full.names = T)

# Lettura files
my_df <- read.csv(all_goodreads_files[1], row.names = 1, stringsAsFactors = F)

# Ottenere solo testo e libro
my_df <- my_df[,c("book", "review")]

# Iterare sugli altri file (nel caso ci fossero; ricordiamo passaggio importante...)
if(length(all_goodreads_files) > 1){
  
  for(i in 2:length(all_goodreads_files)){
    
    # Leggere i datasets uno ad uno
    my_tmp_df <- read.csv(all_goodreads_files[i], row.names = 1, stringsAsFactors = F)
    my_tmp_df <- my_tmp_df[,c("book", "review")]
    
    #Concatenare
    my_df <- rbind(my_df, my_tmp_df)
    
  }
  
  
}

# escludere le recensioni "NA" (probabilmente a causa di errori nello scraping)
my_df <- my_df[!is.na(my_df$review),]

#Aggiungere lingua (in questo caso inglese perchè le recensioni sono in lingua inglese)
my_df$language <- sapply(my_df$review, function(x) detect_language(text = x))

# Alcuni stats
my_df %>% count(language)

# riduci a eng
my_df <- my_df %>% filter(language == "en")

# Rimuovere le informazioni sulla lingua (ormai inutili)
my_df$language <- NULL

# Salvare tutto
save(my_df, file = "corpora/GoodreadsSAExam.RData")

# iInstallare e caricare pacchetti per il SA
install.packages("syuzhet")

library(syuzhet)


install.packages("reshape2")

library(reshape2)

library(tidyverse)

# Emozioni basi nelle recensioni 

# Caricare il file con il nome che gli è stato assegnato
load("corpora/GoodreadsSAExam.RData")

# troviamo i valori emotivi per una recensione
get_nrc_sentiment(my_df$review[1])

# aggiungiamo questi valori a tutte le recensioni
emotion_values <- data.frame()

# interagiamo in tutte le recensioni
for(i in 1:length(my_df$review)){
  
  emotion_values <- rbind(emotion_values, get_nrc_sentiment(my_df$review[i]))
  
}

# normalizzare per lunghezza della revisione
my_df$length <- lengths(strsplit(my_df$review, "\\W"))

# Interagire su tutte le recensioni
for(i in 1:length(my_df$review)){
  
  emotion_values[i,] <- emotion_values[i,]/my_df$length[i]
  
}

# Uniamo i dataframes
my_df <- cbind(my_df, emotion_values)

# Prendiamo due titoli da mettere a confronto
unique(my_df$book) 

my_books <- unique(my_df$book)[c(1,5)]
my_books

# creare un sottoinsieme del dataframe con i soli due libri
my_df_red <- my_df %>% filter(book %in% my_books)
my_df_red$review <- NULL
my_df_red$length <- NULL

# visualizzazione 1: grafico a barre
# calcola le medie

my_df_red_mean <- my_df_red %>%
  group_by(book) %>%
  summarise_all(list(mean = mean))

#  fondere il dataframe
my_df_red_mean <- melt(my_df_red_mean)

# visualizzare plot
p1 <- ggplot(my_df_red_mean, aes(x=variable, y=value, fill=book))+
  geom_bar(stat="identity", position = "dodge")
p1

# salvare plot
ggsave(p1, filename = "figures/3.Sentiment_analysis/Goodreads_plot_01.png", height = 9, width = 16)

# migliore plot
p2 <- ggplot(my_df_red_mean, aes(x=variable, y=value, fill=book))+
  geom_bar(stat="identity", position = "dodge")+
  theme(axis.text.x = element_text(angle = 90, hjust=1))
p2

# salvare plot
ggsave(p2, filename = "figures/3.Sentiment_analysis/Goodreads_plot_02.png", height = 9, width = 16, scale = 0.5)

# visualizzazione 2: boxplot
# fusione di dataframe
my_df_red_mean <- melt(my_df_red)

# fare plot
p3 <- ggplot(my_df_red_mean, aes(x=variable, y=value, fill=book))+
  geom_boxplot(position = "dodge")+
  theme(axis.text.x = element_text(angle = 90, hjust=1))
p3

# salvare plot
ggsave(p3, filename = "figures/3.Sentiment_analysis/Goodreads_esame.png", height = 9, width = 16, scale = 0.5)













